package com.spring.manyto.Manyto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManytoApplication.class, args);
	}

}
