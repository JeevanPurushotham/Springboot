package com.Spring.mapping.ManyToManyProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToManyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
