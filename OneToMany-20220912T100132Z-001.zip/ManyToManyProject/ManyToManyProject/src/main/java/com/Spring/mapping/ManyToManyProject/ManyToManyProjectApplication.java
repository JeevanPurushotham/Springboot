package com.Spring.mapping.ManyToManyProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManyToManyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManyToManyProjectApplication.class, args);
	}

}
