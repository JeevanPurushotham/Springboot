package com.spring.oneto.Mapping.controller;

import com.spring.oneto.Mapping.Repository.CourseRepo;
import com.spring.oneto.Mapping.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @Autowired
    private CourseRepo courseRepo;

    @PostMapping("/save")
    public Course saveCourse(@RequestBody Course course){
        return courseRepo.save(course);
    }

}
