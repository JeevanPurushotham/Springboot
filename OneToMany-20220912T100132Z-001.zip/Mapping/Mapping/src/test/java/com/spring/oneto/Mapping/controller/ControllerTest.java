package com.spring.oneto.Mapping.controller;

import com.spring.oneto.Mapping.Repository.CourseRepo;
import com.spring.oneto.Mapping.entity.Course;
import com.spring.oneto.Mapping.entity.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
@SpringBootTest
class ControllerTest {
    @Autowired
    CourseRepo courseRepo;

    @Test
    void saveCourse() {
        Teacher teacher1 = Teacher.builder()
                .teacherName("Gireesh")
                .build();
        Teacher teacher2 = Teacher.builder()
                .teacherName("Jeevan")
                .build();
        Course course = Course.builder()
                .courseName("Springweb")
                .teacher(Arrays.asList(teacher1,teacher2))
                .build();
        courseRepo.save(course);


    }
}