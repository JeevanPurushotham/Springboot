package com.spring.jpa.OneToManyandManyToONe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyandManyToONeApplicationTests {

	@Test
	void contextLoads() {
	}

}
