package com.spring.jpa.OneToManyandManyToONe.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Store {
    @Id
//    @SequenceGenerator(name = "mynumber",sequenceName = "mynumber",allocationSize = 1,initialValue = 500)
//    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "mynumber")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int storeId;
    private String storeName;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "personfk")
    private List<Person> person;
}
