package com.spring.jpa.OneToManyandManyToONe.repo;

import com.spring.jpa.OneToManyandManyToONe.entity.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonRepo extends JpaRepository<Person,Integer> {
}
