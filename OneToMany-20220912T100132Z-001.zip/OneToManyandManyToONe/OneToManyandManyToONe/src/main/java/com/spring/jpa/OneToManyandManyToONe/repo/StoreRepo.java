package com.spring.jpa.OneToManyandManyToONe.repo;

import com.spring.jpa.OneToManyandManyToONe.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreRepo extends JpaRepository<Store,Integer> {
}
