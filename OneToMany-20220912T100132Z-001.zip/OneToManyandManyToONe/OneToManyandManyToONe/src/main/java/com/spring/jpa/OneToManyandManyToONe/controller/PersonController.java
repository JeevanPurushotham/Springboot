package com.spring.jpa.OneToManyandManyToONe.controller;

import com.spring.jpa.OneToManyandManyToONe.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

public class PersonController {
    @Autowired
    PersonController personController;
    @PostMapping("/save")
    public Person save(Person person) {
        return personController.save(person);
    }
//
//    @GetMapping("/get")
//    public List<Person> getBYId(Person person){
//        return person.getId(person);
//    }
}
