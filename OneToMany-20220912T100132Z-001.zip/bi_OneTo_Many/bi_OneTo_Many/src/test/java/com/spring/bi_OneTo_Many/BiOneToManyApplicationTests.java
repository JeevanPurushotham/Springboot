package com.spring.bi_OneTo_Many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiOneToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
