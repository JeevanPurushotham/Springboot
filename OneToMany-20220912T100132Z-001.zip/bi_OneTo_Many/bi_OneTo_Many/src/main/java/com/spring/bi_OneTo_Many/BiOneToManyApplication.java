package com.spring.bi_OneTo_Many;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiOneToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiOneToManyApplication.class, args);
	}

}
