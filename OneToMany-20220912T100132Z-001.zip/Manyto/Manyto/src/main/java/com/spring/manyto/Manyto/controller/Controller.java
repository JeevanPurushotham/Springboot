package com.spring.manyto.Manyto.controller;


import com.spring.manyto.Manyto.Repository.MobileRepository;
import com.spring.manyto.Manyto.Repository.PersonRepository;
import com.spring.manyto.Manyto.entity.Mobile;
import com.spring.manyto.Manyto.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class Controller {
    @Autowired
    private  MobileRepository mobileRepository;
    @Autowired
    private PersonRepository personRepository;

    @PostMapping("/save")
    public Person getCourse(@RequestBody Person person) {
        return personRepository.save(person);
    }
    @PostMapping("/save1")
    public  List<Mobile> savemobile(@RequestBody List<Mobile> mobile){
//        Person p=new Person();
//        p.setPersonName("Jeewan");
//
//        Mobile mobile=new Mobile();
//        mobile.setMobileName("sdewf");
//        mobile.setPerson(p);
//
//        Mobile mobile1=new Mobile();
//        mobile1.setMobileName("sdewf");
//        mobile1.setPerson(p);

        return mobileRepository.saveAll(mobile);
    }

    @GetMapping("/get")
    public List<Person> getAll(){
        return personRepository.findAll();
    }
}
