package com.spring.manyto.Manyto.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Person {
    @Id
    @SequenceGenerator(name = "PersonSequence",sequenceName = "PersonSequence",allocationSize = 1,initialValue = 400)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator =  "PersonSequence")
    private int personId;
    private String personName;


}
