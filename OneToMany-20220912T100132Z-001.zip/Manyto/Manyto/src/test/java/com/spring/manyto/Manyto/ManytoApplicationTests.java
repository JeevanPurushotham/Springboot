package com.spring.manyto.Manyto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytoApplicationTests {

	@Test
	void contextLoads() {
	}

}
