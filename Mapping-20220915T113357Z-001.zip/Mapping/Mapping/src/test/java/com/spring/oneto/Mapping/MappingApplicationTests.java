package com.spring.oneto.Mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
