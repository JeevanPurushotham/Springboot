package com.spring.jpa.OneToManyandManyToONe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyandManyToONeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToManyandManyToONeApplication.class, args);
	}

}
